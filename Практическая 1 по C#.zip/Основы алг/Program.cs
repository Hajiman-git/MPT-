﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
 

            while (true)
            {
                try
                {
                    Console.WriteLine("Введите 1 число: ");
                    double x = double.Parse(Console.ReadLine());

                    Console.WriteLine("Введите 2 число: ");
                    double y = double.Parse(Console.ReadLine());

                    Console.WriteLine("Выберите оператор: + - * /");
                    string znak = Console.ReadLine();

                    double result;

                    if (znak == "+")
                    {
                        result = x + y;
                        Console.WriteLine("Ответ: " + result);
                    }
                    else if (znak == "-")
                    {
                        result = x - y;
                        Console.WriteLine("Ответ: " + result);
                    }
                    else if (znak == "*")
                    {
                        result = x * y;
                        Console.WriteLine("Ответ: " + result);
                    }
                    else if (znak == "/")
                    {
                        if (y != 0)
                        {
                            result = x / y;
                            Console.WriteLine("Ответ: " + result);
                        }
                        else
                        {
                            Console.WriteLine("Ошибка: Деление на ноль невозможно!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Введен не корректный оператор");
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Ошибка: Введено не числовое значение!");
                }
             

                Console.WriteLine("Нажмите для продолжения");
                Console.ReadLine();
                Console.Clear();
            }






        }

    }
}